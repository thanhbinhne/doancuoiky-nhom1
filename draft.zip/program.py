from Modules.Login import Login_View as lgv
if __name__ == "__main__":
    app = lgv.Login_View()
    app.window.mainloop()